from distutils.core import setup

setup(name='palindrome',
      version='1.0',
      py_modules=['palindrome'],
#metadata
      author="Devashish Nigam",
      author_email="thyanchor@gmail.com",
      description="Finding Palindrome nums",
      license="MIT",
      keywords="exemple",
      )


# C:\Users\dnigam\PycharmProjects\PlurasightPractice\palindrome>python -m venv palindrome_env
#
# C:\Users\dnigam\PycharmProjects\PlurasightPractice\palindrome>cd palindrome_env/Scripts
#
# C:\Users\dnigam\PycharmProjects\PlurasightPractice\palindrome\palindrome_env\Scripts>activate
#
# (palindrome_env) C:\Users\dnigam\PycharmProjects\PlurasightPractice\palindrome\palindrome_env\Scripts>

# (palindrome_env) C:\Users\dnigam\PycharmProjects\PlurasightPractice\palindrome\palindrome_env\Scripts>cd ..
#
# (palindrome_env) C:\Users\dnigam\PycharmProjects\PlurasightPractice\palindrome\palindrome_env>cd ..
#
# (palindrome_env) C:\Users\dnigam\PycharmProjects\PlurasightPractice\palindrome>python setup.py install
# running install
# running build
# running build_py
# copying palindrome.py -> build\lib
# running install_lib
# copying build\lib\palindrome.py -> C:\Users\dnigam\PycharmProjects\PlurasightPractice\palindrome\palindrome_env\Lib\site-packages
# byte-compiling C:\Users\dnigam\PycharmProjects\PlurasightPractice\palindrome\palindrome_env\Lib\site-packages\palindrome.py to palindrome.cpython-37.pyc
# running install_egg_info
# Removing C:\Users\dnigam\PycharmProjects\PlurasightPractice\palindrome\palindrome_env\Lib\site-packages\palindrome-1.0-py3.7.egg-info
# Writing C:\Users\dnigam\PycharmProjects\PlurasightPractice\palindrome\palindrome_env\Lib\site-packages\palindrome-1.0-py3.7.egg-info
#
# (palindrome_env) C:\Users\dnigam\PycharmProjects\PlurasightPractice\palindrome>


# (palindrome_env) C:\Users\dnigam\PycharmProjects\PlurasightPractice\palindrome>cd ..
#
#
# (palindrome_env) C:\Users\dnigam\PycharmProjects\PlurasightPractice>python
# Python 3.7.1 (default, Dec 10 2018, 22:54:23) [MSC v.1915 64 bit (AMD64)] :: Anaconda, Inc. on win32
# Type "help", "copyright", "credits" or "license" for more information.
# >>> import palindrome
# >>> palindrome.__file__
# 'C:\\Users\\dnigam\\PycharmProjects\\PlurasightPractice\\palindrome\\palindrome_env\\lib\\site-packages\\palindrome.py'
# >>>
# >>> exit()
#
# (palindrome_env) C:\Users\dnigam\PycharmProjects\PlurasightPractice>cd palindrome
# (palindrome_env) C:\Users\dnigam\PycharmProjects\PlurasightPractice\palindrome>dir
#  Volume in drive C is WINDOWS
#  Volume Serial Number is AA35-5E2C
#
#  Directory of C:\Users\dnigam\PycharmProjects\PlurasightPractice\palindrome
#
# 09-04-2020  02:19    <DIR>          .
# 09-04-2020  02:19    <DIR>          ..
# 09-04-2020  02:13    <DIR>          build
# 09-04-2020  02:14               326 palindrome.py
# 09-04-2020  02:08    <DIR>          palindrome_env
# 09-04-2020  02:19             2,368 setup.py
#                2 File(s)          2,694 bytes
#                4 Dir(s)  287,529,353,216 bytes free
#
# (palindrome_env) C:\Users\dnigam\PycharmProjects\PlurasightPractice\palindrome>